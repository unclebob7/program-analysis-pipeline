#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
   directory traversal and recursively apply splint upon C file
"""

import os

pj = "/home/bob/Development/flawfinder_repo/raw/test_folder"
pj_name = pj[pj.rindex( '/' ) + 1 : len(pj)]
store_path = "./spl_repo/" + pj_name
if not os.path.exists(store_path):
    os.makedirs(store_path)

def pj_traversal(folder):
    for name in os.listdir(folder):
        if os.path.isdir(os.path.join(folder, name)):
            pj_traversal(os.path.join(folder, name))
        elif name.endswith(".c"):
            # call splint to output the csv file
            full_path = os.path.join(folder, name)
            print(folder)
            print(name)
            print(full_path)
            os.system("./spl.sh" + " " + pj_name + " " + name + " " + full_path)
            
pj_traversal(pj)