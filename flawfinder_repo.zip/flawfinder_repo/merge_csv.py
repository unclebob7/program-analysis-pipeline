#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
    csv concatenation
"""

import pandas as pd
import glob
import os

def merge_csv(indir):
    os.chdir(indir)
    fileList=glob.glob("*.csv")
    print(fileList)
    output_file = pd.concat([pd.read_csv(filename) for filename in fileList])
    output_file.to_csv("_output.csv", index=False)

merge_csv("./spl_repo/test_folder1")