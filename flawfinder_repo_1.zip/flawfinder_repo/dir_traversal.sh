#!/bin/bash
# recursive directory traversal
# $1: project dir to traverse;	$2: output csv file name

traverse_dir()
{
    filepath=$1
    
    for file in `ls -a $filepath`
    do
        if [ -d ${filepath}/$file ]
        then
            if [[ $file != '.' && $file != '..' ]]
            then
                #递归
                traverse_dir ${filepath}/$file
            fi
        else
            #调用查找指定后缀文件
            check_suffix ${filepath}/$file
        fi
    done
}
 
check_suffix()
{
    file=$1
    
    if [ "${file##*.}"x = "c"x ];then
        echo $file
    fi    
}


traverse_dir $1

# splint -csv ./test.csv test.c
