#!/bin/bash
## $1: project name
## $2: C file name
## $3: C file path
pj_name=./spl_repo/$1
file_name=${pj_name}/$2.csv
splint -csv $file_name $3
